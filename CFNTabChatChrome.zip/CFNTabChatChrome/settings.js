document.addEventListener('DOMContentLoaded', () => {
    const backBtn = document.getElementById('back-btn');
    const themeToggle = document.getElementById('theme-toggle');
    const apiSettingsForm = document.getElementById('api-settings-form');
    const aiProviderSelect = document.getElementById('ai-provider');
    const formFieldsContainer = document.getElementById('form-fields');
    const saveStatus = document.getElementById('save-status');

    // --- Theme Management ---
    chrome.storage.sync.get('theme', ({ theme }) => {
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
            themeToggle.checked = true;
        }
    });

    themeToggle.addEventListener('change', () => {
        const theme = themeToggle.checked ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', theme);
        chrome.storage.sync.set({ theme });
    });

    backBtn.addEventListener('click', () => {
        window.location.href = 'popup.html';
    });

    // --- API Settings Management ---
    const providerFields = {
        openai: [
            { name: 'apiKey', label: 'API Key', type: 'password' },
            { name: 'model', label: 'Model', type: 'text', default: 'gpt-4-turbo' }
        ],
        anthropic: [
            { name: 'apiKey', label: 'API Key', type: 'password' },
            { name: 'model', label: 'Model', type: 'text', default: 'claude-3-opus-20240229' }
        ],
        google: [
            { name: 'apiKey', label: 'API Key', type: 'password' },
            { name: 'model', label: 'Model', type: 'text', default: 'gemini-pro' }
        ],
        openrouter: [
            { name: 'apiKey', label: 'API Key', type: 'password' },
            { name: 'model', label: 'Model (comma-separated)', type: 'textarea', placeholder: 'e.g. google/gemini-pro,anthropic/claude-3-opus' }
        ]
    };

    aiProviderSelect.addEventListener('change', (e) => {
        renderFormFields(e.target.value);
    });

    apiSettingsForm.addEventListener('submit', (e) => {
        e.preventDefault();
        saveSettings();
    });

    function renderFormFields(provider) {
        formFieldsContainer.innerHTML = '';
        const fields = providerFields[provider];

        if (fields) {
            fields.forEach(field => {
                const fieldGroup = document.createElement('div');
                fieldGroup.className = 'form-section';

                const label = document.createElement('label');
                label.className = 'form-label';
                label.setAttribute('for', `field-${field.name}`);
                label.textContent = field.label;

                let input;
                if (field.type === 'textarea') {
                    input = document.createElement('textarea');
                    input.className = 'form-textarea';
                    input.placeholder = field.placeholder || '';
                    input.rows = 3;
                } else {
                    input = document.createElement('input');
                    input.className = 'form-input';
                    input.type = field.type;
                    input.placeholder = field.default || '';
                }
                input.id = `field-${field.name}`;
                input.name = field.name;
                
                fieldGroup.appendChild(label);
                fieldGroup.appendChild(input);
                formFieldsContainer.appendChild(fieldGroup);
            });
        }
        loadProviderSettings(provider);
    }

    function loadProviderSettings(provider) {
        chrome.storage.sync.get(['apiSettings'], ({ apiSettings }) => {
            if (apiSettings && apiSettings[provider]) {
                const settings = apiSettings[provider];
                for (const key in settings) {
                    const input = document.getElementById(`field-${key}`);
                    if (input) {
                        input.value = settings[key];
                    }
                }
            }
        });
    }

    function saveSettings() {
        const provider = aiProviderSelect.value;
        const formData = new FormData(apiSettingsForm);
        let newSettings = { provider };
        let providerSettings = {};

        const fields = providerFields[provider];
        fields.forEach(field => {
            providerSettings[field.name] = document.getElementById(`field-${field.name}`).value;
        });

        chrome.storage.sync.get(['apiSettings'], ({ apiSettings }) => {
            if (!apiSettings) apiSettings = {};
            apiSettings[provider] = providerSettings;
            apiSettings.selectedProvider = provider;

            chrome.storage.sync.set({ apiSettings }, () => {
                saveStatus.textContent = 'Settings saved successfully!';
                setTimeout(() => saveStatus.textContent = '', 2000);
            });
        });
    }

    // Initial load
    chrome.storage.sync.get(['apiSettings'], ({ apiSettings }) => {
        const provider = apiSettings?.selectedProvider || 'openrouter';
        aiProviderSelect.value = provider;
        renderFormFields(provider);
    });
});
