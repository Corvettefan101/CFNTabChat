// --- Installation & Defaults ---
chrome.runtime.onInstalled.addListener(() => {
    console.log('Cascade AI Browser extension installed.');
    chrome.storage.sync.get(['apiSettings', 'theme'], (data) => {
        if (!data.apiSettings) {
            chrome.storage.sync.set({
                theme: 'light',
                apiSettings: {
                    selectedProvider: 'openrouter',
                    openrouter: { apiKey: '', model: 'google/gemini-pro' },
                    openai: { apiKey: '', model: 'gpt-4-turbo' },
                    anthropic: { apiKey: '', model: 'claude-3-opus-20240229' },
                    google: { apiKey: '', model: 'gemini-pro' }
                }
            });
        }
    });
});

// --- Message Listeners ---
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'getTabs') {
        handleGetTabs(sendResponse);
        return true; // Indicates async response
    }
    if (message.type === 'chatMessage') {
        handleChatMessage(message.text, message.mentionedTabIds || []);
        return true; // Indicates async response
    }
    if (message.type === 'updateStyles') {
        // Update the katex-styles.css file
        const blob = new Blob([message.styles], { type: 'text/css' });
        const url = URL.createObjectURL(blob);
        
        // Create a download URL for the styles
        const link = document.createElement('a');
        link.href = url;
        link.download = 'katex-styles.css';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Clean up
        setTimeout(() => URL.revokeObjectURL(url), 100);
        
        sendResponse({ success: true });
        return true;
    }
    if (message.type === 'externalRequest') {
        const processRequest = async () => {
            try {
                const response = await fetch(message.url, {
                    method: message.options.method,
                    headers: message.options.headers,
                    body: message.options.body,
                    mode: 'cors'
                });
                
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, body: ${errorText}`);
                }
                
                const data = await response.json();
                return { success: true, data };
            } catch (error) {
                console.error('External request failed:', error);
                return { 
                    success: false,
                    error: error.message,
                    stack: error.stack 
                };
            }
        };
        
        // Process the request and send the response
        processRequest().then(result => {
            if (chrome.runtime.lastError) {
                console.error('Runtime error:', chrome.runtime.lastError);
                sendResponse({
                    success: false,
                    error: chrome.runtime.lastError.message
                });
            } else {
                sendResponse(result);
            }
        });
        
        return true; // Required for async sendResponse
    }
    
    // Explicitly handle unknown message types
    sendResponse({ success: false, error: 'Unknown message type' });
    return false;
});

// --- Tab Management ---
function handleGetTabs(sendResponse) {
    chrome.tabs.query({}, (tabs) => {
        const tabInfo = tabs.map(tab => ({
            id: tab.id,
            title: tab.title,
            url: tab.url,
            favIconUrl: tab.favIconUrl
        }));
        sendResponse(tabInfo);
    });
}

// --- Content Scraping ---
async function getTabContent(tabUrl) {
    if (!tabUrl || tabUrl.startsWith('chrome://')) {
        return { content: 'This is a special browser page and cannot be accessed.', title: 'Special Page' };
    }
    try {
        const response = await fetch(`https://r.jina.ai/${tabUrl}`, {
            headers: {
                'Accept': 'application/json'
            }
        });
        if (!response.ok) {
            throw new Error(`Jina API Error: ${response.status} ${response.statusText}`);
        }
        const data = await response.json();
        // Jina returns content in markdown format, which is great for LLMs.
        return { content: data.data.content, title: data.data.title };
    } catch (error) {
        console.error(`Error getting content from URL ${tabUrl}:`, error);
        return { content: `Failed to fetch content from the page.`, title: "Content Fetch Error" };
    }
}

// --- Chat Logic ---
async function handleChatMessage(messageText, mentionedTabIds) {
    chrome.runtime.sendMessage({ type: 'aiResponseStart' });

    const { apiSettings } = await chrome.storage.sync.get('apiSettings');
    if (!apiSettings || !apiSettings.selectedProvider) {
        chrome.runtime.sendMessage({ type: 'aiResponse', text: "AI provider not configured. Please go to settings." });
        return;
    }

    const provider = apiSettings.selectedProvider;
    const settings = apiSettings[provider];
    if (!settings || !settings.apiKey) {
        chrome.runtime.sendMessage({ type: 'aiResponse', text: `API key for ${provider} is missing. Please add it in settings.` });
        return;
    }

    try {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        let mainContent = await getTabContent(activeTab.url);

        let mentionedContents = [];
        if (mentionedTabIds.length > 0) {
            const mentionedTabs = await Promise.all(mentionedTabIds.map(id => chrome.tabs.get(id)));
            const contentPromises = mentionedTabs.map(tab => getTabContent(tab.url));
            mentionedContents = await Promise.all(contentPromises);
        }

        let prompt = `User question: "${messageText}"\n\n`;
        prompt += `Context from current tab (${mainContent.title}):\n---\n${mainContent.content}\n---\n\n`;
        if (mentionedContents.length > 0) {
            prompt += "Additional context from other tabs:\n";
            mentionedContents.forEach(mc => {
                prompt += `Context from tab "${mc.title}":\n---\n${mc.content}\n---\n\n`;
            });
        }
        prompt += "Based on the provided context, answer the user's question.";

        const aiResponse = await callAiProvider(provider, settings, prompt);
        chrome.runtime.sendMessage({ type: 'aiResponse', text: aiResponse });

    } catch (error) {
        console.error("Error processing chat message:", error);
        chrome.runtime.sendMessage({ type: 'aiResponse', text: `An error occurred: ${error.message}` });
    }
}

// --- AI Provider API Calls ---
async function callAiProvider(provider, settings, prompt) {
    console.log(`Calling ${provider} API with model: ${settings.model}`);
    
    // Rate limiting state
    const rateLimits = {
        lastRequest: 0,
        minDelay: 1000 // 1 second minimum between requests
    };
    
    // Calculate delay since last request
    const now = Date.now();
    const timeSinceLastRequest = now - rateLimits.lastRequest;
    if (timeSinceLastRequest < rateLimits.minDelay) {
        await new Promise(resolve => setTimeout(resolve, rateLimits.minDelay - timeSinceLastRequest));
    }
    
    // Common request function for all providers with retry logic
    const makeRequest = async (endpoint, requestOptions, retries = 3, backoff = 1000) => {
        const makeAttempt = async (attempt) => {
            let response;
            let responseText;
            
            try {
                // Update last request time
                rateLimits.lastRequest = Date.now();
                
                // Log request details (redacting sensitive info)
                const logHeaders = { ...requestOptions.headers };
                if (logHeaders.Authorization) {
                    logHeaders.Authorization = '***';
                }
                
                console.log(`[${new Date().toISOString()}] [Attempt ${attempt}] Making ${requestOptions.method} request to:`, endpoint, {
                    method: requestOptions.method,
                    headers: logHeaders,
                    body: requestOptions.body ? '***' : undefined
                });
                
                const startTime = Date.now();
                
                try {
                    // Make the request with a timeout
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
                    
                    response = await fetch(endpoint, {
                        ...requestOptions,
                        signal: controller.signal,
                        mode: 'cors',
                        credentials: 'omit',
                        referrerPolicy: 'no-referrer'
                    });
                    
                    clearTimeout(timeoutId);
                    
                    // Get response text first (we'll parse as JSON if possible)
                    responseText = await response.text();
                    
                    const responseTime = Date.now() - startTime;
                    
                    // Log response details
                    console.log(`[${new Date().toISOString()}] [Attempt ${attempt}] Received response in ${responseTime}ms:`, {
                        status: response.status,
                        statusText: response.statusText,
                        url: response.url,
                        headers: Object.fromEntries(response.headers.entries()),
                        body: responseText.length > 500 ? 
                              `${responseText.substring(0, 200)}...${responseText.substring(-200)}` : 
                              responseText
                    });
                    
                    // Parse JSON if possible
                    let data;
                    try {
                        data = responseText ? JSON.parse(responseText) : null;
                    } catch (e) {
                        // If not JSON, use the text as data
                        data = responseText;
                    }
                    
                    // Attach response to error for better error handling
                    const errorWithResponse = (message) => {
                        const error = new Error(message);
                        error.response = response;
                        error.responseData = data;
                        return error;
                    };
                    
                    // Handle rate limiting (429) and server errors (5xx)
                    if (response.status === 429) {
                        const retryAfter = parseInt(response.headers?.get('retry-after') || '5', 10) * 1000 || 
                                         Math.min(backoff * Math.pow(2, attempt - 1), 30000); // Max 30s backoff
                        console.warn(`[${new Date().toISOString()}] Rate limited. Retrying after ${retryAfter}ms`);
                        throw errorWithResponse('Rate limited');
                    } 
                    
                    // Handle other error statuses
                    if (!response.ok) {
                        if (response.status >= 500) {
                            throw errorWithResponse(`Server error: ${response.status} ${response.statusText}`);
                        } else if (response.status === 401) {
                            throw errorWithResponse('Unauthorized - Please check your API key');
                        } else if (response.status === 403) {
                            throw errorWithResponse('Forbidden - Check API permissions');
                        } else if (response.status === 404) {
                            throw errorWithResponse('Endpoint not found');
                        } else if (response.status === 400) {
                            const errorMsg = data?.error?.message || 
                                          data?.message ||
                                          (typeof data === 'string' ? data : JSON.stringify(data)) ||
                                          `Bad request (${response.status})`;
                            throw errorWithResponse(errorMsg);
                        } else {
                            const errorMsg = data?.error?.message || 
                                          (typeof data === 'string' ? data : JSON.stringify(data)) ||
                                          `HTTP error! status: ${response.status}`;
                            throw errorWithResponse(errorMsg);
                        }
                    }
                    
                    return data;
                    
                } catch (error) {
                    clearTimeout(timeoutId);
                    if (error.name === 'AbortError') {
                        throw new Error('Request timed out after 30 seconds');
                    }
                    throw error;
                }
                
            } catch (error) {
                // Attach response info to error if not already attached
                if (response && !error.response) {
                    error.response = response;
                    error.responseText = responseText;
                }
                
                console.error(`[${new Date().toISOString()}] Error in makeRequest (attempt ${attempt}):`, {
                    message: error.message,
                    status: error.response?.status,
                    url: error.response?.url || endpoint,
                    responseData: error.responseData || error.responseText,
                    stack: error.stack
                });
                
                // Don't retry for client errors (4xx) except 429 (already handled)
                const isClientError = error.response?.status >= 400 && error.response?.status < 500;
                if (isClientError && error.response?.status !== 429) {
                    console.error('Client error, not retrying:', error.message);
                    throw error;
                }
                throw error;
            }
        };
        
        return makeAttempt(1);
    };

    // Variables for API request configuration
    let endpoint;
    let headers;
    let body;

    try {
        switch (provider) {
            case 'anthropic':
                endpoint = 'https://api.anthropic.com/v1/messages';
                headers = { 
                    'Content-Type': 'application/json',
                    'x-api-key': settings.apiKey,
                    'anthropic-version': '2023-06-01'
                };
                body = { 
                    model: settings.model, 
                    max_tokens: 4096, 
                    messages: [{ role: 'user', content: prompt }] 
                };
                
                console.log('Sending Anthropic request...');
                const anthropicResponse = await makeRequest(endpoint, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify(body)
                });
                
                console.log('Received Anthropic response:', anthropicResponse);
                
                if (anthropicResponse?.content?.[0]?.text) {
                    return anthropicResponse.content[0].text;
                } else if (anthropicResponse?.error) {
                    throw new Error(`Anthropic API error: ${anthropicResponse.error.message || JSON.stringify(anthropicResponse.error)}`);
                } else {
                    throw new Error('Invalid response format from Anthropic');
                }
                
            case 'google':
                endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${settings.model}:generateContent?key=${settings.apiKey}`;
                headers = { 'Content-Type': 'application/json' };
                body = { 
                    contents: [{ 
                        parts: [{ text: prompt }] 
                    }] 
                };
                
                console.log('Sending Google request...');
                const googleResponse = await makeRequest(endpoint, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify(body)
                });
                
                console.log('Received Google response:', googleResponse);
                
                if (googleResponse?.candidates?.[0]?.content?.parts?.[0]?.text) {
                    return googleResponse.candidates[0].content.parts[0].text;
                } else if (googleResponse?.error) {
                    throw new Error(`Google API error: ${googleResponse.error.message || JSON.stringify(googleResponse.error)}`);
                } else {
                    throw new Error('Invalid response format from Google');
                }
            case 'openrouter':
                endpoint = 'https://openrouter.ai/api/v1/chat/completions';
                
                // Validate API key
                if (!settings.apiKey) {
                    throw new Error('OpenRouter API key is not configured. Please add your API key in the extension settings.');
                }

                // Normalize and validate model name
                let model = settings.model.trim();
                if (!model) {
                    throw new Error('No model specified. Please select a model in the settings.');
                }

                // Enhanced model mapping with fallbacks and versioning
                const modelMappings = {
                    // DeepSeek models
                    'deepseek': 'deepseek/deepseek-chat',
                    'deepseek-chat': 'deepseek/deepseek-chat',
                    'deepseek-coder': 'deepseek/deepseek-coder',
                    'deepseek-r1': 'deepseek/deepseek-r1-0528-qwen3-8b:free',
                    
                    // OpenAI models with version mapping
                    'gpt-4': 'openai/gpt-4-turbo',  // Default to latest GPT-4 version
                    'gpt-4-turbo': 'openai/gpt-4-turbo',
                    'gpt-4-turbo-preview': 'openai/gpt-4-turbo-preview',
                    'gpt-4-32k': 'openai/gpt-4-32k',
                    'gpt-3.5': 'openai/gpt-3.5-turbo',
                    'gpt-3.5-turbo': 'openai/gpt-3.5-turbo',
                    
                    // Anthropic models
                    'claude-3': 'anthropic/claude-3-opus',
                    'claude-3-opus': 'anthropic/claude-3-opus',
                    'claude-3-sonnet': 'anthropic/claude-3-sonnet',
                    'claude-3-haiku': 'anthropic/claude-3-haiku',
                    'claude-2': 'anthropic/claude-2',
                    
                    // Google models
                    'gemini': 'google/gemini-pro',
                    'gemini-pro': 'google/gemini-pro',
                    'gemini-1.5': 'google/gemini-1.5-pro',
                    'gemini-1.5-pro': 'google/gemini-1.5-pro',
                    
                    // Mistral models
                    'mistral': 'mistralai/mixtral-8x7b-instruct',
                    'mistral-medium': 'mistralai/mistral-medium',
                    'mixtral': 'mistralai/mixtral-8x7b-instruct',
                    'mixtral-8x7b': 'mistralai/mixtral-8x7b-instruct',
                    
                    // Meta models
                    'llama-2': 'meta-llama/llama-2-70b-chat',
                    'llama-2-70b': 'meta-llama/llama-2-70b-chat',
                    'llama-3': 'meta-llama/llama-3-70b-instruct',
                    'llama-3-70b': 'meta-llama/llama-3-70b-instruct'
                };

                // Only use the exact model specified in settings, no fallbacks
                if (!model) {
                    throw new Error('No OpenRouter model specified. Please set a model in the settings.');
                }
                
                // Special handling for DeepSeek models
                if (model.includes('deepseek-r1-0528:free')) {
                    throw new Error('The DeepSeek R1 model is no longer available. Please use a different model.');
                }
                
                const openRouterModel = model; // Use exactly what was specified
                console.log(`[OpenRouter] Using specified model: ${openRouterModel}`);
                
                // Prepare the request with enhanced metadata and parameters
                const requestHeaders = { 
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${settings.apiKey}`,
                    'HTTP-Referer': 'https://cfn-tab-chat.example.com',
                    'X-Title': 'CFN Tab Chat',
                    'X-OpenRouter-Version': '1.0.0',
                    'X-OpenRouter-Client': 'cfn-tab-chat/1.0.0',
                    'Accept': 'application/json'
                };
                
                const requestBody = { 
                    model: openRouterModel,
                    messages: [
                        {
                            role: 'system',
                            content: 'You are a helpful assistant. Provide accurate and concise responses.'
                        },
                        { 
                            role: 'user',
                            content: prompt
                        }
                    ],
                    temperature: 0.7,
                    max_tokens: 4096,
                    top_p: 0.9,
                    stream: false,
                    transforms: ['middleware-empty']
                };
                
                console.log(`[OpenRouter] Sending request to ${endpoint}`, {
                    model: openRouterModel,
                    original_model: model,
                    prompt_length: prompt.length,
                    headers: { ...requestHeaders, 'Authorization': 'Bearer ***' },
                    body: {
                        ...requestBody,
                        messages: [
                            { ...requestBody.messages[0] },
                            { 
                                ...requestBody.messages[1], 
                                content: requestBody.messages[1].content.substring(0, 100) + 
                                       (requestBody.messages[1].content.length > 100 ? '...' : '')
                            }
                        ]
                    }
                });
                
                // Implement enhanced retry logic with exponential backoff and jitter
                const maxRetries = 5;
                let lastError = null;
                let lastResponse = null;
                
                for (let attempt = 1; attempt <= maxRetries; attempt++) {
                    try {
                        const startTime = Date.now();
                        
                        const response = await makeRequest(
                            endpoint,
                            {
                                method: 'POST',
                                headers: requestHeaders,
                                body: JSON.stringify(requestBody)
                            },
                            1,  // Single attempt per retry (we handle retries here)
                            1000 // Base delay
                        );
                        
                        const responseTime = Date.now() - startTime;
                        lastResponse = response;
                        
                        if (!response) {
                            throw new Error('No response received from OpenRouter API');
                        }
                        
                        // Log response metrics with model verification
                        const actualModel = response.model || 'unknown';
                        if (actualModel !== openRouterModel) {
                            console.warn(`[OpenRouter] Warning: Requested model '${openRouterModel}' but received response from '${actualModel}'`);
                        }
                        
                        console.log(`[OpenRouter] Response received in ${responseTime}ms (attempt ${attempt}/${maxRetries}):`, {
                            requested_model: openRouterModel,
                            actual_model: actualModel,
                            status: 'success',
                            response_id: response.id,
                            usage: response.usage || {},
                            finish_reason: response.choices?.[0]?.finish_reason
                        });
                        
                        // Check for error in response
                        if (response.error) {
                            const errorMsg = response.error.message || 
                                          response.error.code || 
                                          JSON.stringify(response.error);
                            throw new Error(`OpenRouter API error: ${errorMsg}`);
                        }
                        
                        // Validate response format
                        if (response.choices?.[0]?.message?.content) {
                            return response.choices[0].message.content;
                        } else if (response.choices?.[0]?.message) {
                            // Handle cases where content might be empty but message exists
                            return ''; // Return empty string for empty responses
                        } else {
                            throw new Error('Invalid response format from OpenRouter: Missing content in response');
                        }
                        
                    } catch (error) {
                        lastError = error;
                        console.error(`[OpenRouter] Attempt ${attempt} failed:`, error.message);
                        
                        // Don't retry on client errors (except 429)
                        if (error.response?.status >= 400 && 
                            error.response?.status < 500 && 
                            error.response?.status !== 429) {
                            break;
                        }
                        
                        // Calculate wait time with exponential backoff and jitter
                        if (attempt < maxRetries) {
                            const baseDelay = 1000; // 1 second
                            const jitter = Math.random() * 1000; // Add up to 1s jitter
                            const backoff = baseDelay * Math.pow(2, attempt - 1) + jitter;
                            
                            console.log(`[OpenRouter] Retrying in ${Math.ceil(backoff/1000)}s... (${attempt}/${maxRetries})`);
                            await new Promise(resolve => setTimeout(resolve, backoff));
                        }
                    }
                }
                
                // If we get here, all retries failed
                const errorMessage = lastError?.message || 'Unknown error';
                
                // Provide user-friendly error messages
                if (errorMessage.includes('401') || errorMessage.includes('Unauthorized')) {
                    throw new Error('Invalid OpenRouter API key. Please check your API key in settings.');
                } else if (errorMessage.includes('429') || errorMessage.includes('rate limit')) {
                    throw new Error('Rate limited by OpenRouter. Please wait a moment and try again.');
                } else if (errorMessage.includes('model') || errorMessage.includes('not found')) {
                    throw new Error(`Model not supported: ${model}. Please try a different model.`);
                } else if (errorMessage.includes('quota') || errorMessage.includes('limit')) {
                    throw new Error('API quota exceeded. Please check your OpenRouter account limits.');
                } else if (errorMessage.includes('network')) {
                    throw new Error('Network error. Please check your internet connection and try again.');
                } else {
                    // Generic error with more context
                    let errorDetails = errorMessage;
                    if (lastError?.response?.status) {
                        errorDetails = `HTTP ${lastError.response.status}: ${errorMessage}`;
                    }
                    throw new Error(`OpenRouter API error: ${errorDetails}`);
                }
            default:
                throw new Error('Unsupported AI provider.');
        }

        // This should never be reached as all providers should be handled in the switch
        throw new Error(`Unhandled provider: ${provider}. This should not happen.`);
    } catch (error) {
        // Log the full error for debugging
        console.error('Error in callAiProvider:', {
            error: error.message,
            stack: error.stack,
            provider,
            model: settings?.model
        });
        
        // Rethrow with a more user-friendly message
        throw new Error(`Failed to call ${provider} API: ${error.message}`);
    }
}
