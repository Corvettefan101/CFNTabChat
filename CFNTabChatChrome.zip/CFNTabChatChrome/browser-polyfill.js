// Browser API compatibility layer
// This ensures the extension works in both Chrome and Firefox

// Create browser namespace if it doesn't exist
if (typeof browser === 'undefined') {
    // In Chrome, the browser API is chrome.*
    // Create a browser object that maps to chrome
    window.browser = {
        // Storage API
        storage: {
            sync: {
                get: (keys, callback) => chrome.storage.sync.get(keys, callback),
                set: (items, callback) => chrome.storage.sync.set(items, callback || (() => {})),
                remove: (keys, callback) => chrome.storage.sync.remove(keys, callback || (() => {})),
                clear: (callback) => chrome.storage.sync.clear(callback || (() => {}))
            },
            local: {
                get: (keys, callback) => chrome.storage.local.get(keys, callback),
                set: (items, callback) => chrome.storage.local.set(items, callback || (() => {})),
                remove: (keys, callback) => chrome.storage.local.remove(keys, callback || (() => {})),
                clear: (callback) => chrome.storage.local.clear(callback || (() => {}))
            }
        },
        
        // Tabs API
        tabs: {
            query: (queryInfo) => new Promise(resolve => chrome.tabs.query(queryInfo, resolve)),
            get: (tabId) => new Promise(resolve => chrome.tabs.get(tabId, resolve)),
            create: (createProperties) => new Promise(resolve => chrome.tabs.create(createProperties, resolve)),
            update: (tabId, updateProperties) => new Promise(resolve => chrome.tabs.update(tabId, updateProperties, resolve)),
            remove: (tabIds) => new Promise(resolve => chrome.tabs.remove(tabIds, resolve)),
            sendMessage: (tabId, message, options) => new Promise((resolve, reject) => {
                chrome.tabs.sendMessage(tabId, message, options, (response) => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                    } else {
                        resolve(response);
                    }
                });
            })
        },
        
        // Runtime API
        runtime: {
            getURL: (path) => chrome.runtime.getURL(path),
            sendMessage: (message, responseCallback) => chrome.runtime.sendMessage(message, responseCallback),
            onMessage: chrome.runtime.onMessage,
            onInstalled: chrome.runtime.onInstalled,
            getManifest: () => chrome.runtime.getManifest(),
            getPlatformInfo: () => new Promise(resolve => chrome.runtime.getPlatformInfo(resolve)),
            openOptionsPage: () => new Promise(resolve => chrome.runtime.openOptionsPage(resolve))
        },
        
        // Commands API
        commands: {
            onCommand: chrome.commands.onCommand
        },
        
        // Action API (for Manifest V3)
        action: {
            setIcon: (details) => new Promise(resolve => chrome.action.setIcon(details, resolve)),
            setTitle: (details) => new Promise(resolve => chrome.action.setTitle(details, resolve)),
            setBadgeText: (details) => new Promise(resolve => chrome.action.setBadgeText(details, resolve)),
            setBadgeBackgroundColor: (details) => new Promise(resolve => chrome.action.setBadgeBackgroundColor(details, resolve))
        },
        
        // Alarms API
        alarms: {
            create: (name, alarmInfo) => new Promise(resolve => chrome.alarms.create(name, alarmInfo, resolve)),
            get: (name) => new Promise(resolve => chrome.alarms.get(name, resolve)),
            getAll: () => new Promise(resolve => chrome.alarms.getAll(resolve)),
            clear: (name) => new Promise(resolve => chrome.alarms.clear(name, resolve)),
            onAlarm: chrome.alarms.onAlarm
        },
        
        // Notifications API
        notifications: {
            create: (notificationId, options, callback) => 
                chrome.notifications.create(notificationId, options, callback),
            clear: (notificationId, callback) => 
                chrome.notifications.clear(notificationId, callback)
        },
        
        // Context Menus API
        contextMenus: {
            create: (createProperties, callback) => 
                chrome.contextMenus.create(createProperties, callback),
            remove: (menuItemId, callback) => 
                chrome.contextMenus.remove(menuItemId, callback)
        },
        
        // i18n API
        i18n: {
            getMessage: (messageName, substitutions) => 
                chrome.i18n.getMessage(messageName, substitutions),
            getUILanguage: () => chrome.i18n.getUILanguage()
        },
        
        // WebNavigation API
        webNavigation: {
            onCompleted: chrome.webNavigation.onCompleted,
            onHistoryStateUpdated: chrome.webNavigation.onHistoryStateUpdated
        },
        
        // Windows API
        windows: {
            create: (createData) => new Promise(resolve => chrome.windows.create(createData, resolve)),
            get: (windowId, getInfo) => new Promise(resolve => chrome.windows.get(windowId, getInfo, resolve)),
            getCurrent: (getInfo) => new Promise(resolve => chrome.windows.getCurrent(getInfo, resolve)),
            getLastFocused: (getInfo) => new Promise(resolve => chrome.windows.getLastFocused(getInfo, resolve)),
            getAll: (getInfo) => new Promise(resolve => chrome.windows.getAll(getInfo, resolve)),
            update: (windowId, updateInfo) => new Promise(resolve => chrome.windows.update(windowId, updateInfo, resolve)),
            remove: (windowId) => new Promise(resolve => chrome.windows.remove(windowId, resolve))
        },
        
        // Bookmarks API
        bookmarks: {
            create: (bookmark) => new Promise(resolve => chrome.bookmarks.create(bookmark, resolve)),
            get: (idOrIdList) => new Promise(resolve => chrome.bookmarks.get(idOrIdList, resolve)),
            getChildren: (id) => new Promise(resolve => chrome.bookmarks.getChildren(id, resolve)),
            getRecent: (numberOfItems) => new Promise(resolve => chrome.bookmarks.getRecent(numberOfItems, resolve)),
            getSubTree: (id) => new Promise(resolve => chrome.bookmarks.getSubTree(id, resolve)),
            getTree: () => new Promise(resolve => chrome.bookmarks.getTree(resolve)),
            move: (id, destination) => new Promise(resolve => chrome.bookmarks.move(id, destination, resolve)),
            remove: (id) => new Promise(resolve => chrome.bookmarks.remove(id, resolve)),
            removeTree: (id) => new Promise(resolve => chrome.bookmarks.removeTree(id, resolve)),
            search: (query) => new Promise(resolve => chrome.bookmarks.search(query, resolve)),
            update: (id, changes) => new Promise(resolve => chrome.bookmarks.update(id, changes, resolve)),
            onCreated: chrome.bookmarks.onCreated,
            onRemoved: chrome.bookmarks.onRemoved,
            onChanged: chrome.bookmarks.onChanged,
            onMoved: chrome.bookmarks.onMoved,
            onChildrenReordered: chrome.bookmarks.onChildrenReordered,
            onImportBegan: chrome.bookmarks.onImportBegan,
            onImportEnded: chrome.bookmarks.onImportEnded
        }
    };
}

// Add promise-based API support for Firefox
if (browser && !browser.tabs.query.then) {
    // Convert callback-based APIs to promise-based
    ['tabs', 'windows', 'storage', 'runtime', 'browsingData', 'sessions', 'downloads', 'commands'].forEach(apiNamespace => {
        if (!browser[apiNamespace]) return;
        
        Object.keys(browser[apiNamespace]).forEach(apiMethod => {
            if (typeof browser[apiNamespace][apiMethod] === 'function' && 
                !browser[apiNamespace][apiMethod].toString().includes('return new Promise')) {
                const originalMethod = browser[apiNamespace][apiMethod];
                browser[apiNamespace][apiMethod] = function(...args) {
                    if (args.length > 0 && typeof args[args.length - 1] === 'function') {
                        // Callback style
                        return originalMethod.apply(this, args);
                    }
                    // Promise style
                    return new Promise((resolve, reject) => {
                        originalMethod(...args, (result) => {
                            if (chrome.runtime.lastError) {
                                reject(chrome.runtime.lastError);
                            } else {
                                resolve(result);
                            }
                        });
                    });
                };
            }
        });
    });
}

// Export for modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = browser;
}
