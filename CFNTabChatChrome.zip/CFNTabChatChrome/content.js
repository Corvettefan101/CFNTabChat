// Content script for CFN Tab Chat extension
// This script runs in the context of web pages and handles communication with the extension

// Inject KaTeX styles into the extension's CSS file
function updateKatexStyles(styles) {
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = chrome.runtime.getURL('katex-styles.css');
  document.head.appendChild(link);
  
  // Add dynamic styles to the CSS file
  const styleContent = `
    /* KaTeX styles */
    ${styles}
    
    .katex { font-size: 1.1em; }
    .katex-display { margin: 0.5em 0; }
    .katex-html { text-align: left; }
  `;
  
  // Update the CSS file
  chrome.runtime.sendMessage({
    type: 'updateStyles',
    styles: styleContent
  });
}

// Listen for messages from the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'getPageContent') {
    // Get the page content
    const pageContent = {
      url: window.location.href,
      title: document.title,
      text: document.body.innerText,
      html: document.documentElement.outerHTML
    };
    
    // Send the content back to the extension
    sendResponse(pageContent);
  } else if (request.type === 'updateKatexStyles') {
    updateKatexStyles(request.styles);
    sendResponse({ success: true });
  }
  
  // Return true to indicate we want to send a response asynchronously
  return true;
});

// Function to extract clean text from the page
function extractCleanText() {
  // Remove script and style elements
  const elementsToRemove = document.querySelectorAll('script, style, noscript, iframe, object, embed');
  elementsToRemove.forEach(el => el.remove());
  
  // Get the main content
  const content = document.body.innerText
    .replace(/\s+/g, ' ') // Replace multiple whitespace with single space
    .trim();
    
  return content;
}

// Expose a function to get clean text
window.getCleanText = extractCleanText;
