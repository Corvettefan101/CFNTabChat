document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.getElementById('settings-btn');
    const newChatBtn = document.getElementById('new-chat-btn');
    const chatInput = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const chatMessages = document.getElementById('chat-messages');
    const tabMentionContainer = document.getElementById('tab-mention-container');
    const currentTabContextContainer = document.getElementById('current-tab-context');
    const mentionedTabsContainer = document.getElementById('mentioned-tabs-container');

    let tabMentionQuery = '';
    let isMentioning = false;
    let mentionedTabs = [];

    async function loadCurrentTabContext() {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (tab && tab.url) {
            let hostname = '';
            try {
                hostname = new URL(tab.url).hostname;
            } catch (e) {
                // Handles special URLs like chrome://extensions
                hostname = tab.url.split('/')[0] || 'Special Page';
            }

            const pillHTML = `
                <div class="context-pill">
                    <img src="${tab.favIconUrl || 'icons/icon16.png'}" class="context-pill-icon" alt="favicon">
                    <div class="context-pill-info">
                        <div class="context-pill-title">${tab.title || 'Untitled'}</div>
                        <div class="context-pill-url">${hostname}</div>
                    </div>
                </div>
            `;
            currentTabContextContainer.innerHTML = pillHTML;
        }
    }

    // Apply theme & load initial data
    chrome.storage.sync.get('theme', ({ theme }) => {
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    });
    loadCurrentTabContext();

    settingsBtn.addEventListener('click', () => {
        window.location.href = 'settings.html';
    });

    newChatBtn.addEventListener('click', startNewChat);

    function startNewChat() {
        chatMessages.innerHTML = '';
        mentionedTabs = [];
        renderMentionedPills();
        displayMessage("Hello! How can I help you today?", 'ai');
    }

    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    chatInput.addEventListener('input', handleTabMentions);

    function sendMessage() {
        const messageText = chatInput.value.trim();
        const mentionedTabIds = mentionedTabs.map(t => t.id);

        // Only send if there's text or at least one tab mentioned.
        if (messageText || mentionedTabIds.length > 0) {
            displayMessage(messageText, 'user');
            chrome.runtime.sendMessage({ 
                type: 'chatMessage', 
                text: messageText,
                mentionedTabIds: mentionedTabIds
            });
            chatInput.value = '';
            chatInput.style.height = 'auto';
        }
    }

    function formatMarkdown(text) {
        // Escape HTML to prevent XSS
        let html = String(text)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
        
        // Convert basic formatting
        html = html
            // Convert **bold** and *italic*
            .replace(/\*\*([^*]+?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*([^*]+?)\*/g, '<em>$1</em>')
            .replace(/__([^_]+?)__/g, '<strong>$1</strong>')
            .replace(/_([^_]+?)_/g, '<em>$1</em>')
            
            // Convert newlines to <br> and paragraphs
            .replace(/\n\s*\n/g, '</p><p>')
            .replace(/\n/g, '<br>')
            
            // Convert lists (basic support)
            .replace(/^\s*\*\s+(.+)$/gm, '<li>$1</li>')
            .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
            
            // Convert numbered lists
            .replace(/^\s*\d+\.\s+(.+)$/gm, '<li>$1</li>')
            .replace(/(<li>.*<\/li>)/gs, function(match) {
                return match.includes('<ul>') ? match : '<ol>' + match + '</ol>';
            });
            
        // Wrap in paragraph tags if not already wrapped
        if (!html.startsWith('<') || html.startsWith('<br')) {
            html = '<p>' + html + '</p>';
        }
        
        // Process any LaTeX in the text
        if (typeof processLatex === 'function') {
            html = processLatex(html);
        }
        
        // Clean up any remaining formatting issues
        html = html
            .replace(/\n{3,}/g, '\n\n')  // Fix multiple consecutive newlines
            .replace(/<\/li>\s*<\/ul>\s*<p>/g, '</li>\n</ul>\n<p>');  // Ensure proper spacing after lists
        
        return html;
    }

    function displayMessage(text, sender, isLoading = false) {
        const messageEl = document.createElement('div');
        messageEl.classList.add('message', sender);
        
        if (isLoading) {
            messageEl.innerHTML = '<div class="loader"></div>';
        } else if (sender === 'ai') {
            messageEl.innerHTML = formatMarkdown(text);
        } else {
            messageEl.textContent = text;
        }
        
        chatMessages.appendChild(messageEl);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return messageEl;
    }

    async function handleTabMentions(e) {
        const text = e.target.value;
        const mentionMatch = text.match(/@(\w*)$/);

        if (mentionMatch) {
            isMentioning = true;
            tabMentionQuery = mentionMatch[1].toLowerCase();
            const allTabs = await chrome.runtime.sendMessage({ type: 'getTabs' });
            const filteredTabs = allTabs.filter(tab => 
                tab.title.toLowerCase().includes(tabMentionQuery) || 
                tab.url.toLowerCase().includes(tabMentionQuery)
            );
            renderTabMentions(filteredTabs);
        } else {
            if (isMentioning) {
                isMentioning = false;
                tabMentionContainer.classList.add('hidden');
            }
        }
    }

    function renderTabMentions(tabs) {
        tabMentionContainer.innerHTML = '';
        if (tabs.length > 0) {
            tabMentionContainer.classList.remove('hidden');
            tabs.forEach(tab => {
                const tabItem = document.createElement('div');
                tabItem.className = 'tab-item';
                tabItem.innerHTML = `<img src="${tab.favIconUrl || 'icons/icon16.png'}" alt="favicon"> <span>${tab.title}</span>`;
                tabItem.addEventListener('click', () => selectTabMention(tab));
                tabMentionContainer.appendChild(tabItem);
            });
        } else {
            tabMentionContainer.classList.add('hidden');
        }
    }

    function selectTabMention(tab) {
        if (!mentionedTabs.find(t => t.id === tab.id)) {
            mentionedTabs.push(tab);
            renderMentionedPills();
        }

        // Clear the @mention trigger text from the input field
        const currentValue = chatInput.value;
        const newValue = currentValue.replace(/@\w*$/, '');
        chatInput.value = newValue;
        tabMentionContainer.classList.add('hidden');
        isMentioning = false;
        chatInput.focus();
    }

    function renderMentionedPills() {
        mentionedTabsContainer.innerHTML = '';
        mentionedTabs.forEach(tab => {
            const pill = document.createElement('div');
            pill.className = 'mentioned-pill';
            pill.dataset.tabId = tab.id;
            pill.innerHTML = `
                <img src="${tab.favIconUrl || 'icons/icon16.png'}" alt="favicon">
                <span>${tab.title}</span>
                <button class="remove-pill-btn">×</button>
            `;
            mentionedTabsContainer.appendChild(pill);

            pill.querySelector('.remove-pill-btn').addEventListener('click', () => {
                removeMentionedTab(tab.id);
            });
        });
    }

    function removeMentionedTab(tabId) {
        mentionedTabs = mentionedTabs.filter(t => t.id !== tabId);
        renderMentionedPills();
    }

    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'aiResponse') {
            const botMessages = document.querySelectorAll('.message.bot .loader');
            if (botMessages.length > 0) {
                const lastBotMessage = botMessages[botMessages.length - 1].parentElement;
                lastBotMessage.innerHTML = ''; // Clear loader
                lastBotMessage.textContent = message.text;
            } else {
                displayMessage(message.text, 'ai');
            }
        } else if (message.type === 'aiResponseStart') {
            displayMessage('', 'bot', true);
        }
    });
});
