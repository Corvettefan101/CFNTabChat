$ErrorActionPreference = "Stop"

# Create lib directory if it doesn't exist
$libDir = Join-Path $PSScriptRoot "lib"
if (-not (Test-Path $libDir)) {
    New-Item -ItemType Directory -Path $libDir | Out-Null
}

# Download marked.js
$markedUrl = "https://cdn.jsdelivr.net/npm/marked/marked.min.js"
$markedPath = Join-Path $libDir "marked.min.js"
Invoke-WebRequest -Uri $markedUrl -OutFile $markedPath

# Download KaTeX
$katexUrl = "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"
$katexPath = Join-Path $libDir "katex.min.js"
Invoke-WebRequest -Uri $katexUrl -OutFile $katexPath

# Download KaTeX CSS
$katexCssUrl = "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css"
$katexCssPath = Join-Path $libDir "katex.min.css"
Invoke-WebRequest -Uri $katexCssUrl -OutFile $katexCssPath

# Download KaTeX auto-render
$katexAutoRenderUrl = "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"
$katexAutoRenderPath = Join-Path $libDir "auto-render.min.js"
Invoke-WebRequest -Uri $katexAutoRenderUrl -OutFile $katexAutoRenderPath

Write-Host "All libraries downloaded successfully to $libDir"
