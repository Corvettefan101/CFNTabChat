# Cascade AI Browser Extension

Chat with your browser tabs, powered by your favorite AI models.

## Features

*   **Chat with any tab:** Open the extension to start a conversation about the content of your active tab.
*   **@Mention Tabs:** Bring other open tabs into the conversation for multi-document context.
*   **Multiple AI Providers:** Connect your own API keys for OpenRouter, OpenAI, Anthropic, and Google.
*   **Custom Models:** For OpenRouter, specify any model you want to use.
*   **Sleek UI:** A modern, clean interface with a dark mode option.

## How to Install

1.  Clone or download this repository.
2.  Open Chrome and navigate to `chrome://extensions`.
3.  Enable "Developer mode" in the top right corner.
4.  Click "Load unpacked" and select the directory where you saved the extension files.
5.  The Cascade AI Browser icon should appear in your extensions toolbar.

## How to Use

1.  Click the extension icon to open the chat popup.
2.  Go to the **Settings** page (⚙️ icon) to add your API keys for the AI provider you want to use.
3.  Start asking questions about the current page!
4.  To reference another tab, type `@` and start typing the tab's title or URL. A list of matching tabs will appear. Click one to add it to your message.

## File Structure

*   `manifest.json`: Configures the extension.
*   `popup.html` / `popup.css` / `popup.js`: The main chat interface.
*   `settings.html` / `settings.css` / `settings.js`: The settings panel.
*   `background.js`: The service worker that handles all core logic.
*   `content.js`: Injected into pages to scrape content.
*   `lib/Readability.js`: A library for cleaning up page content.
*   `icons/`: Extension icons.
