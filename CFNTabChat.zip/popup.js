document.addEventListener('DOMContentLoaded', () => {
    const settingsBtn = document.getElementById('settings-btn');
    const newChatBtn = document.getElementById('new-chat-btn');
    const chatInput = document.getElementById('chat-input');
    const sendBtn = document.getElementById('send-btn');
    const chatMessages = document.getElementById('chat-messages');
    const tabMentionContainer = document.getElementById('tab-mention-container');
    const currentTabContextContainer = document.getElementById('current-tab-context');
    const mentionedTabsContainer = document.getElementById('mentioned-tabs-container');

    let tabMentionQuery = '';
    let isMentioning = false;
    let mentionedTabs = [];

    async function loadCurrentTabContext() {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        if (tab && tab.url) {
            let hostname = '';
            try {
                hostname = new URL(tab.url).hostname;
            } catch (e) {
                // Handles special URLs like chrome://extensions
                hostname = tab.url.split('/')[0] || 'Special Page';
            }

            const pillHTML = `
                <div class="context-pill">
                    <img src="${tab.favIconUrl || 'icons/icon16.png'}" class="context-pill-icon" alt="favicon">
                    <div class="context-pill-info">
                        <div class="context-pill-title">${tab.title || 'Untitled'}</div>
                        <div class="context-pill-url">${hostname}</div>
                    </div>
                </div>
            `;
            currentTabContextContainer.innerHTML = pillHTML;
        }
    }

    // Apply theme & load initial data
    chrome.storage.sync.get('theme', ({ theme }) => {
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    });
    loadCurrentTabContext();

    settingsBtn.addEventListener('click', () => {
        window.location.href = 'settings.html';
    });

    newChatBtn.addEventListener('click', startNewChat);

    function startNewChat() {
        chatMessages.innerHTML = '';
        mentionedTabs = [];
        renderMentionedPills();
        displayMessage("Hello! How can I help you today?", 'ai');
    }

    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    chatInput.addEventListener('input', handleTabMentions);

    function sendMessage() {
        const messageText = chatInput.value.trim();
        const mentionedTabIds = mentionedTabs.map(t => t.id);

        // Only send if there's text or at least one tab mentioned.
        if (messageText || mentionedTabIds.length > 0) {
            displayMessage(messageText, 'user');
            chrome.runtime.sendMessage({ 
                type: 'chatMessage', 
                text: messageText,
                mentionedTabIds: mentionedTabIds
            });
            chatInput.value = '';
            chatInput.style.height = 'auto';
        }
    }

    function formatMarkdown(text) {
        // First, pre-process the text to handle lists that might be in a single line
        // This handles cases like "1. First 2. Second 3. Third" or "* One * Two * Three"
        text = text.replace(/(\d+\.\s+[^\n]+(\s+\*\s+[^\n]+)*)/g, (match) => {
            // Split by number patterns (e.g., "1. ", "2. ", etc.)
            return '\n' + match.replace(/(\d+\.\s+)/g, '\n$1');
        });

        // Handle bullet points in a single line
        text = text.replace(/(\*\s+[^\n]+(\s+\*\s+[^\n]+)*)/g, (match) => {
            // Split by bullet points
            return '\n' + match.replace(/(\*\s+)/g, '\n* ');
        });

        // Ensure proper spacing around lists
        text = text.replace(/\n(\s*[\*\-\d]\.?\s+)/g, '\n\n$1');

        // Configure marked with custom renderer for better control
        const renderer = new marked.Renderer();
        
        // Customize list rendering for better formatting
        renderer.listitem = function(text) {
            // Remove any leading/trailing whitespace and newlines
            text = text.trim();
            // Ensure list items have proper spacing
            return `<li>${text}</li>\n`;
        };
        
        // Customize code block rendering for potential LaTeX
        renderer.code = function(code, language) {
            // Check if this is a math code block
            if (language === 'math') {
                try {
                    return katex.renderToString(code, { displayMode: true });
                } catch (e) {
                    return `<pre class="katex-error">${e.message}</pre>`;
                }
            }
            // Regular code block
            return `<pre><code class="language-${language || ''}">${code}</code></pre>`;
        };

        // Customize inline code for potential LaTeX
        renderer.codespan = function(code) {
            // Check if this is an inline math expression
            if (code.startsWith('$') && code.endsWith('$') && code.length > 2) {
                try {
                    return katex.renderToString(code.slice(1, -1), { displayMode: false });
                } catch (e) {
                    return `<code class="katex-error">${e.message}</code>`;
                }
            }
            return `<code>${code}</code>`;
        };

        // Configure marked options
        marked.setOptions({
            renderer: renderer,
            gfm: true,  // GitHub Flavored Markdown
            tables: true, // Enable tables
            breaks: false, // Don't convert '\n' to <br> - we want proper paragraphs
            smartLists: true, // Better list handling
            smartypants: true, // Smart quotes and other typographic enhancements
            xhtml: true, // Use XHTML-compatible tags
            highlight: function(code, lang) {
                return code;
            }
        });

        // Process markdown to HTML
        let html = marked.parse(text);
        
        // Process any remaining LaTeX expressions not caught by the code blocks
        // This handles standalone $$...$$ and $...$ expressions
        html = html.replace(/\$\$([^$]+)\$\$/g, (_, math) => {
            try {
                return katex.renderToString(math, { displayMode: true });
            } catch (e) {
                return `<span class="katex-error">${e.message}</span>`;
            }
        }).replace(/\$([^$]+)\$/g, (_, math) => {
            try {
                return katex.renderToString(math, { displayMode: false });
            } catch (e) {
                return `<span class="katex-error">${e.message}</span>`;
            }
        });

        // Ensure proper spacing between list items
        html = html.replace(/<li>/g, '<li style="margin-bottom: 0.5em;">');
        
        return html;
    }

    function displayMessage(text, sender, isLoading = false) {
        const messageEl = document.createElement('div');
        messageEl.classList.add('message', sender);
        
        if (isLoading) {
            messageEl.innerHTML = '<div class="loader"></div>';
        } else if (sender === 'ai') {
            messageEl.innerHTML = formatMarkdown(text);
        } else {
            messageEl.textContent = text;
        }
        
        chatMessages.appendChild(messageEl);
        chatMessages.scrollTop = chatMessages.scrollHeight;
        return messageEl;
    }

    async function handleTabMentions(e) {
        const text = e.target.value;
        const mentionMatch = text.match(/@(\w*)$/);

        if (mentionMatch) {
            isMentioning = true;
            tabMentionQuery = mentionMatch[1].toLowerCase();
            const allTabs = await chrome.runtime.sendMessage({ type: 'getTabs' });
            const filteredTabs = allTabs.filter(tab => 
                tab.title.toLowerCase().includes(tabMentionQuery) || 
                tab.url.toLowerCase().includes(tabMentionQuery)
            );
            renderTabMentions(filteredTabs);
        } else {
            if (isMentioning) {
                isMentioning = false;
                tabMentionContainer.classList.add('hidden');
            }
        }
    }

    function renderTabMentions(tabs) {
        tabMentionContainer.innerHTML = '';
        if (tabs.length > 0) {
            tabMentionContainer.classList.remove('hidden');
            tabs.forEach(tab => {
                const tabItem = document.createElement('div');
                tabItem.className = 'tab-item';
                tabItem.innerHTML = `<img src="${tab.favIconUrl || 'icons/icon16.png'}" alt="favicon"> <span>${tab.title}</span>`;
                tabItem.addEventListener('click', () => selectTabMention(tab));
                tabMentionContainer.appendChild(tabItem);
            });
        } else {
            tabMentionContainer.classList.add('hidden');
        }
    }

    function selectTabMention(tab) {
        if (!mentionedTabs.find(t => t.id === tab.id)) {
            mentionedTabs.push(tab);
            renderMentionedPills();
        }

        // Clear the @mention trigger text from the input field
        const currentValue = chatInput.value;
        const newValue = currentValue.replace(/@\w*$/, '');
        chatInput.value = newValue;
        tabMentionContainer.classList.add('hidden');
        isMentioning = false;
        chatInput.focus();
    }

    function renderMentionedPills() {
        mentionedTabsContainer.innerHTML = '';
        mentionedTabs.forEach(tab => {
            const pill = document.createElement('div');
            pill.className = 'mentioned-pill';
            pill.dataset.tabId = tab.id;
            pill.innerHTML = `
                <img src="${tab.favIconUrl || 'icons/icon16.png'}" alt="favicon">
                <span>${tab.title}</span>
                <button class="remove-pill-btn">×</button>
            `;
            mentionedTabsContainer.appendChild(pill);

            pill.querySelector('.remove-pill-btn').addEventListener('click', () => {
                removeMentionedTab(tab.id);
            });
        });
    }

    function removeMentionedTab(tabId) {
        mentionedTabs = mentionedTabs.filter(t => t.id !== tabId);
        renderMentionedPills();
    }

    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === 'aiResponse') {
            const botMessages = document.querySelectorAll('.message.bot .loader');
            if (botMessages.length > 0) {
                const lastBotMessage = botMessages[botMessages.length - 1].parentElement;
                lastBotMessage.innerHTML = ''; // Clear loader
                lastBotMessage.textContent = message.text;
            } else {
                displayMessage(message.text, 'ai');
            }
        } else if (message.type === 'aiResponseStart') {
            displayMessage('', 'bot', true);
        }
    });
});
